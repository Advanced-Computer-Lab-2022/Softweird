import Searchbar  from "./Searchbar"
function Navbar () {

    return(
        <>
        <Searchbar />
        
        </>
    )
}
export default Navbar