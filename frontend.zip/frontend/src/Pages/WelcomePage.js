import Navbar from "../Components/Navbar";

function WelcomePage() {
    return (
        <></>
    );
}
export default WelcomePage;