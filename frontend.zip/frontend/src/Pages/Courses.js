function AllCourses (){
    return (
        <>
        </>
    )
}
export default AllCourses